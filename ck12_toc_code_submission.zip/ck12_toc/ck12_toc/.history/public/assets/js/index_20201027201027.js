const request = require("supertest");
// Your JS code goes here
var allData ={
    "maths": [
      {
        "childrenCount": 9,
        "id": 4443990,
        "sequenceNO": 1,
        "title": "Ratios",
        "type": "chapter",
        "completeCount": 9
      },
      {
        "childrenCount": 10,
        "id": 4443993,
        "sequenceNO": 2,
        "title": "Rates and Percentages",
        "type": "chapter",
        "completeCount": 4
      },
      {
        "childrenCount": 11,
        "id": 4429482,
        "sequenceNO": 3,
        "title": "Division with Fractions",
        "type": "chapter",
        "completeCount": 0
      },
      {
        "childrenCount": 10,
        "id": 4429484,
        "sequenceNO": 4,
        "title": "Operations with Decimals and Whole Numbers",
        "type": "chapter",
        "completeCount": 10
      },
      {
        "childrenCount": 11,
        "id": 4429490,
        "sequenceNO": 8,
        "title": "Rational Numbers",
        "type": "chapter",
        "completeCount": 2
      },
      {
        "childrenCount": 9,
        "id": 4429495,
        "sequenceNO": 6,
        "title": "Expressions",
        "type": "chapter",
        "completeCount": 4
      },
      {
        "childrenCount": 9,
        "id": 4429496,
        "sequenceNO": 7,
        "title": "Equations",
        "type": "chapter",
        "completeCount": 0
      },
      {
        "childrenCount": 0,
        "id": 1131520,
        "sequenceNO": 5,
        "title": "Fractions Explained in Depth",
        "type": "lesson",
        "status": "COMPLETE"
      }
    ]
  }

  $http.
  show(allData)
function show(data){
    console.log(data.maths);
    for(let i=0;i<data.maths.length;i++){
        var empTab = document.getElementById('contentYellow');
        var li = document.createElement("li");
        var children = empTab.children.length + 1;
        li.setAttribute("id", "element" + children);
        li.setAttribute("class", "list-items");
        li.style.margin = "5px";
       
        empTab.appendChild(li);
        var liId = document.getElementById("element" + children);
        // ADD A BUTTON.
        var icon = document.createElement('i');
        icon.setAttribute('class', 'fa fa-plus');
        icon.style.display = "inline";
        
        var button1 = document.createElement('button');
        // SET INPUT ATTRIBUTE.
        button1.setAttribute('type', 'button');
        button1.setAttribute("id", "button" + children);
        button1.setAttribute('class', 'btn-default collapsible');
        button1.style.display = "inline";
        button1.style.marginTop = "-5px";
        button1.style.borderRadius = "5px";
        button1.appendChild(icon);
        button1.appendChild(document.createTextNode(data.maths[i].title));
        liId.appendChild(button1);
        //<i class="fa fa-plus"></i>
        li.onclick = function() { clickTest(data.maths[i].id,liId); };



    }
    const other = {
        "maths": {
          "4443990": [
            {
              "id": 4423715,
              "sequenceNO": 1,
              "title": "Introducing Ratios - Math 6 CCSS",
              "type": "lesson",
              "status": "COMPLETE"
            },
            {
              "id": 4423719,
              "sequenceNO": 5,
              "title": "Completing Tables of Equivalent Ratios - Math 6 CCSS",
              "type": "lesson",
              "status": "COMPLETE"
            },
            {
              "id": 4423716,
              "sequenceNO": 2,
              "title": "Pictures of Ratios - Math 6 CCSS",
              "type": "lesson",
              "status": "COMPLETE"
            },
            {
              "id": 4423718,
              "sequenceNO": 4,
              "title": "Double Number Lines & Equivalent Ratios - Math 6 CCSS",
              "type": "lesson",
              "status": "COMPLETE"
            },
            {
              "id": 4423720,
              "sequenceNO": 6,
              "title": "Constructing Tables of Equivalent Ratios - Math 6 CCSS",
              "type": "lesson",
              "status": "COMPLETE"
            },
            {
              "id": 4423717,
              "sequenceNO": 3,
              "title": "Equivalent Ratios & Tape Diagrams - Math 6 CCSS",
              "type": "lesson",
              "status": "COMPLETE"
            },
            {
              "id": 4423721,
              "sequenceNO": 7,
              "title": "Comparing Ratios with Tables - Math 6 CCSS",
              "type": "lesson",
              "status": "COMPLETE"
            },
            {
              "id": 4423722,
              "sequenceNO": 8,
              "title": "Pictures of Part-Part-Whole Ratios - Math 6 CCSS",
              "type": "lesson",
              "status": "COMPLETE"
            },
            {
              "id": 4443989,
              "sequenceNO": 9,
              "title": "Part-Part-Whole Ratios with Tape Diagrams - Math 6 CCSS",
              "type": "lesson",
              "status": "COMPLETE"
            }
          ],
          "4443993": [
            {
              "id": 4423729,
              "sequenceNO": 5,
              "title": "Unit Conversion - Math 6 CCSS",
              "type": "lesson",
              "status": "COMPLETE"
            },
            {
              "id": 4423731,
              "sequenceNO": 7,
              "title": "Percentages with Tape Diagrams",
              "type": "lesson",
              "status": "IN_PROGRESS"
            },
            {
              "id": 4423726,
              "sequenceNO": 2,
              "title": "Unit Rates - Math 6 CCSS",
              "type": "lesson",
              "status": "IN_PROGRESS"
            },
            {
              "id": 4423725,
              "sequenceNO": 1,
              "title": "Rates - Math 6 CCSS",
              "type": "lesson",
              "status": "COMPLETE"
            },
            {
              "id": 4423727,
              "sequenceNO": 3,
              "title": "Price Unit Rates - Math 6 CCSS",
              "type": "lesson",
              "status": "NOT_STARTED"
            },
            {
              "id": 4423728,
              "sequenceNO": 4,
              "title": "Constant Speed Unit Rate - Math 6 CCSS",
              "type": "lesson",
              "status": "COMPLETE"
            },
            {
              "id": 4423730,
              "sequenceNO": 6,
              "title": "Introducing Percentages",
              "type": "lesson",
              "status": "COMPLETE"
            },
            {
              "id": 4423732,
              "sequenceNO": 8,
              "title": "Percentages with Double Number Lines",
              "type": "lesson",
              "status": "NOT_STARTED"
            },
            {
              "id": 4423734,
              "sequenceNO": 10,
              "title": "Percent and a Part to Find the Whole - Math 6 CCSS",
              "type": "lesson",
              "status": "NOT_STARTED"
            },
            {
              "id": 4443992,
              "sequenceNO": 9,
              "title": "Percentage of an Amount",
              "type": "lesson",
              "status": "NOT_STARTED"
            }
          ],
          "4429482": [
            {
              "id": 4423744,
              "sequenceNO": 9,
              "title": "Dividing Fractions with Diagrams",
              "type": "lesson",
              "status": "IN_PROGRESS"
            },
            {
              "id": 4423741,
              "sequenceNO": 6,
              "title": "Scaling Shrinking Rectangle",
              "type": "lesson",
              "status": "IN_PROGRESS"
            },
            {
              "id": 4423740,
              "sequenceNO": 5,
              "title": "Finding Rectangle Dimensions",
              "type": "lesson",
              "status": "NOT_STARTED"
            },
            {
              "id": 4423742,
              "sequenceNO": 7,
              "title": "Dividing with Unit Fractions",
              "type": "lesson",
              "status": "NOT_STARTED"
            },
            {
              "id": 4423737,
              "sequenceNO": 2,
              "title": "Dividing into Groups",
              "type": "lesson",
              "status": "IN_PROGRESS"
            },
            {
              "id": 4423746,
              "sequenceNO": 11,
              "title": "Comparison Division",
              "type": "lesson",
              "status": "NOT_STARTED"
            },
            {
              "id": 4423739,
              "sequenceNO": 4,
              "title": "Division as Multiplication",
              "type": "lesson",
              "status": "NOT_STARTED"
            },
            {
              "id": 4423738,
              "sequenceNO": 3,
              "title": "Effect of Dividing with Fractions",
              "type": "lesson",
              "status": "IN_PROGRESS"
            },
            {
              "id": 4423743,
              "sequenceNO": 8,
              "title": "Dividing a Whole Number by a Fraction",
              "type": "lesson",
              "status": "IN_PROGRESS"
            },
            {
              "id": 4423736,
              "sequenceNO": 1,
              "title": "Dividing a Fraction by a Whole Number",
              "type": "lesson",
              "status": "NOT_STARTED"
            },
            {
              "id": 4423745,
              "sequenceNO": 10,
              "title": "Dividing Fractions with the Standard Method",
              "type": "lesson",
              "status": "NOT_STARTED"
            }
          ],
          "4429484": [
            {
              "id": 4423749,
              "sequenceNO": 2,
              "title": "Adding and Subtracting Decimals with the Standard Method",
              "type": "lesson",
              "status": "COMPLETE"
            },
            {
              "id": 4423748,
              "sequenceNO": 1,
              "title": "Adding and Subtracting Decimals with Diagrams",
              "type": "lesson",
              "status": "COMPLETE"
            },
            {
              "id": 4423750,
              "sequenceNO": 3,
              "title": "Multiplying Decimals with Diagrams",
              "type": "lesson",
              "status": "COMPLETE"
            },
            {
              "id": 4423751,
              "sequenceNO": 4,
              "title": "Multiplying Decimals with the Standard Method",
              "type": "lesson",
              "status": "COMPLETE"
            },
            {
              "id": 4423752,
              "sequenceNO": 5,
              "title": "Decimal Quotients with Diagrams",
              "type": "lesson",
              "status": "COMPLETE"
            },
            {
              "id": 4423754,
              "sequenceNO": 7,
              "title": "Dividing Decimals in Diagrams",
              "type": "lesson",
              "status": "COMPLETE"
            },
            {
              "id": 4423753,
              "sequenceNO": 6,
              "title": "Long Division",
              "type": "lesson",
              "status": "COMPLETE"
            },
            {
              "id": 4423756,
              "sequenceNO": 9,
              "title": "Using Greatest Common Factor",
              "type": "lesson",
              "status": "COMPLETE"
            },
            {
              "id": 4423755,
              "sequenceNO": 8,
              "title": "Decimals Divided by Decimals",
              "type": "lesson",
              "status": "COMPLETE"
            },
            {
              "id": 4423757,
              "sequenceNO": 10,
              "title": "Using Least Common Multiple",
              "type": "lesson",
              "status": "COMPLETE"
            }
          ],
          "4429490": [
            {
              "id": 4423769,
              "sequenceNO": 11,
              "title": "Drawing in the Coordinate Plane - Math 6 CCSS",
              "type": "lesson",
              "status": "COMPLETE"
            },
            {
              "id": 4423768,
              "sequenceNO": 10,
              "title": "Absolute Value as Distance on the Coordinate Plane - Math 6 CCSS",
              "type": "lesson",
              "status": "COMPLETE"
            },
            {
              "id": 4423766,
              "sequenceNO": 8,
              "title": "Symmetry on the Coordinate Plane - Math 6 CCSS",
              "type": "lesson",
              "status": "IN_PROGRESS"
            },
            {
              "id": 4423762,
              "sequenceNO": 4,
              "title": "Symmetry on the Number Line - Math 6 CCSS",
              "type": "lesson",
              "status": "IN_PROGRESS"
            },
            {
              "id": 4423760,
              "sequenceNO": 2,
              "title": "Rational Number Line - Math 6 CCSS",
              "type": "lesson",
              "status": "IN_PROGRESS"
            },
            {
              "id": 4423764,
              "sequenceNO": 6,
              "title": "The Four Quadrants - Math 6 CCSS",
              "type": "lesson",
              "status": "IN_PROGRESS"
            },
            {
              "id": 4423765,
              "sequenceNO": 7,
              "title": "Points on the Coordinate Plane - Math 6 CCSS",
              "type": "lesson",
              "status": "NOT_STARTED"
            },
            {
              "id": 4423763,
              "sequenceNO": 5,
              "title": "Absolute Value on Number Line - Math 6 CCSS",
              "type": "lesson",
              "status": "NOT_STARTED"
            },
            {
              "id": 4423761,
              "sequenceNO": 3,
              "title": "Points on the Number Line - Math 6 CCSS",
              "type": "lesson",
              "status": "NOT_STARTED"
            },
            {
              "id": 4423759,
              "sequenceNO": 1,
              "title": "Positives and Negatives - Math 6 CCSS",
              "type": "lesson",
              "status": "NOT_STARTED"
            },
            {
              "id": 4423767,
              "sequenceNO": 9,
              "title": "Distance on the Coordinate Plane - Math 6 CCSS",
              "type": "lesson",
              "status": "NOT_STARTED"
            }
          ],
          "4429495": [
            {
              "id": 4423771,
              "sequenceNO": 1,
              "title": "Expressions - Math 6 CCSS",
              "type": "lesson",
              "status": "COMPLETE"
            },
            {
              "id": 4423772,
              "sequenceNO": 2,
              "title": "Using Exponents - Math 6 CCSS",
              "type": "lesson",
              "status": "COMPLETE"
            },
            {
              "id": 4423773,
              "sequenceNO": 3,
              "title": "Expressions with Exponents - Math 6 CCSS",
              "type": "lesson",
              "status": "COMPLETE"
            },
            {
              "id": 4423775,
              "sequenceNO": 5,
              "title": "Unknown Values - Math 6 CCSS",
              "type": "lesson",
              "status": "IN_PROGRESS"
            },
            {
              "id": 4423774,
              "sequenceNO": 4,
              "title": "Order of Operations - Math 6 CCSS",
              "type": "lesson",
              "status": "COMPLETE"
            },
            {
              "id": 4423777,
              "sequenceNO": 7,
              "title": "Expressions with Variables - Math 6 CCSS",
              "type": "lesson",
              "status": "NOT_STARTED"
            },
            {
              "id": 4423779,
              "sequenceNO": 9,
              "title": "Distributive Property - Math 6 CCSS",
              "type": "lesson",
              "status": "NOT_STARTED"
            },
            {
              "id": 4423778,
              "sequenceNO": 8,
              "title": "Evaluating Expressions - Math 6 CCSS",
              "type": "lesson",
              "status": "NOT_STARTED"
            },
            {
              "id": 4423776,
              "sequenceNO": 6,
              "title": "Letters Stand for Numbers - Math 6 CCSS",
              "type": "lesson",
              "status": "IN_PROGRESS"
            }
          ],
          "4429496": [
            {
              "id": 4423784,
              "sequenceNO": 4,
              "title": "Solving Multiplication Equations - Math 6 CCSS",
              "type": "lesson",
              "status": "IN_PROGRESS"
            },
            {
              "id": 4423781,
              "sequenceNO": 1,
              "title": "Equivalent Expressions - Math 6 CCSS",
              "type": "lesson",
              "status": "IN_PROGRESS"
            },
            {
              "id": 4423785,
              "sequenceNO": 5,
              "title": "Defining Independent and Dependent Variables - Math 6 CCSS",
              "type": "lesson",
              "status": "IN_PROGRESS"
            },
            {
              "id": 4423782,
              "sequenceNO": 2,
              "title": "Solving Equations - Math 6 CCSS",
              "type": "lesson",
              "status": "IN_PROGRESS"
            },
            {
              "id": 4423787,
              "sequenceNO": 7,
              "title": "Analyzing Relationships - Math 6 CCSS",
              "type": "lesson",
              "status": "IN_PROGRESS"
            },
            {
              "id": 4423786,
              "sequenceNO": 6,
              "title": "Writing Equations - Math 6 CCSS",
              "type": "lesson",
              "status": "IN_PROGRESS"
            },
            {
              "id": 4423783,
              "sequenceNO": 3,
              "title": "Solving Addition Equations - Math 6 CCSS",
              "type": "lesson",
              "status": "IN_PROGRESS"
            },
            {
              "id": 4423789,
              "sequenceNO": 9,
              "title": "Equivalent Ratio Equations - Math 6 CCSS",
              "type": "lesson",
              "status": "IN_PROGRESS"
            },
            {
              "id": 4423788,
              "sequenceNO": 8,
              "title": "Making Tables and Graphs - Math 6 CCSS",
              "type": "lesson",
              "status": "IN_PROGRESS"
            }
          ]
        }
      };
    function clickTest(u,liId){
        console.log(u);
        app.get('/api/book/:'+u+'/section/:sectionId');


    }
    


    
  

    // var a = $(this).find("#element" + children);
    // var ListItems = $('#contentYellow').find("#element" + children);
    // while (ListItems.length !== 0) {
    //     //$("#element" + children).remove();
    //     var children = empTab.children.length + getRandomInt(20, 1000);
    //     li.setAttribute("id", "element" + children);
    //     var ListItems = $('#contentYellow').find("#element" + children);
    // }
    // li.setAttribute("class", "list-items");
    // li.style.margin = "5px";
    // //li.appendChild(document.createTextNode("Element "+children));
    // empTab.appendChild(li);
    // var liId = document.getElementById("element" + children);
    // $scope.idSend = document.getElementById("element" + children);
    // // ADD A BUTTON.
    // var button1 = document.createElement('button');
    // // SET INPUT ATTRIBUTE.
    // button1.setAttribute('type', 'button');
    // button1.setAttribute("id", "button" + children);
    // button1.setAttribute('class', 'btn btn-sm btn-default collapsible');
    // button1.style.display = "inline-block";
    // button1.style.marginTop = "-5px";
    // button1.style.borderRadius = "5px";
    // // ADD THE BUTTON's 'onclick' EVENT.
    // //button.setAttribute('ng-click', 'removeRow(this)');
    // liId.appendChild(button1);
    // var buttonId = document.getElementById("button" + children);
    // // compile the element
    // $compile($(buttonId))($scope);

    // // CREATE AND ADD TEXTBOX IN EACH CELL.
    // var ele1 = document.createElement('i');
    // ele1.setAttribute('class', 'fa fa-close');
    // ele1.style.display = "inline-block";
    // buttonId.appendChild(ele1);

    // // ADD A BUTTON.
    // var button = document.createElement('button');

    // // SET INPUT ATTRIBUTE.
    // button.setAttribute('type', 'button');
    // button.setAttribute("id", "buttonAdd" + children);
    // button.setAttribute('class', 'btn btn-sm btn-default');
    // button.style.display = "inline-block";
    // button.style.marginTop = "-5px";
    // button.style.borderRadius = "5px";
    // // ADD THE BUTTON's 'onclick' EVENT.
    // liId.appendChild(button);
    // var buttonAddId = document.getElementById("buttonAdd" + children);
    // //Creating another icon to add
    // var ele2 = document.createElement('i');
    // ele2.setAttribute('class', 'fa fa-plus');
    // ele2.style.display = "inline-block";
    // buttonAddId.appendChild(ele2);
    // // change ng-click
    // $(buttonAddId).attr('ng-click', 'addRow()');
    // // compile the element
    // $compile($(buttonAddId))($scope);

    // // CREATE AND ADD TEXTBOX IN EACH CELL.
    // var ele = document.createElement('input');
    // ele.setAttribute('type', 'text');
    // ele.setAttribute('class', 'form-control');
    // ele.setAttribute("id", "input" + children);
    // ele.setAttribute("ng-model", "row" + children);
    // ele.setAttribute("value", "");
    // ele.setAttribute("placeholder", "Add a Yellow Label");
    // var variable = "row" + children;
    // $scope[variable] = "";
    // ele.style.width = "89%";
    // ele.style.display = "inline-block";
    // ele.style.borderRadius = "5px";
    // ele.style.height = "30px";
    // liId.appendChild(ele);
    // var inputId = document.getElementById("input" + children);
    // $scope.inputTypeId = document.getElementById("input" + children);
    // //$(inputId).attr('required','required');
    // $(inputId).attr('ng-change', 'changeRow(row' + children + ',this)');
    // $compile($(inputId))($scope);
}

var coll = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var content = this.nextElementSibling;
    if (content.style.display === "block") {
      content.style.display = "none";
    } else {
      content.style.display = "block";
    }
  });
}




                   