
  $.ajax({
    type: "GET",
    url: '/api/book/maths',
    dataType: "json",
    success: function(res) {
        const allData = res.response;
        show(allData)
    }
});
 
function show(data){
    for(let i=0;i<data.length;i++){
        var empTab = document.getElementById('contentYellow');
        var li = document.createElement("li");
        var children = empTab.children.length + 1;
        li.setAttribute("id", "element" + children);
        li.setAttribute("class", "list-items");
        li.style.margin = "5px";
       
        empTab.appendChild(li);
        var liId = document.getElementById("element" + children);
        // ADD A BUTTON.
        var icon = document.createElement('i');
        icon.setAttribute('class', 'fa fa-plus');
        icon.style.display = "inline";
        
        var button1 = document.createElement('button');
        // SET INPUT ATTRIBUTE.
        button1.setAttribute('type', 'button');
        button1.setAttribute("id", "button" + children);
        button1.setAttribute('class', 'btn-default collapsible');
        button1.style.display = "inline";
        button1.style.marginTop = "-5px";
        button1.style.borderRadius = "5px";
        button1.appendChild(icon);
        button1.appendChild(document.createTextNode(data[i].title));
        liId.appendChild(button1);
        li.onclick = function() { clickTest(data[i].id,liId); };
    }
}

function clickTest(u){
  $.ajax({
    type: "GET",
    url: 'http://localhost:3000/api/book/maths/section/'+u,
    dataType: "json",
    success: function(res) {
        const subDetails = res.response[u];
        show(subDetails);
    }
});


}
var coll = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var content = this.nextElementSibling;
    if (content.style.display === "block") {
      content.style.display = "none";
    } else {
      content.style.display = "block";
    }
  });
}




                   