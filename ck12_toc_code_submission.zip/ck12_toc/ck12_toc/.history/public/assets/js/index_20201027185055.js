// Your JS code goes here

const api_url = "/api/book/maths/section/"; 
  
// Defining async function 
async function getapi(url) { 
    
    // Storing response 
    const response = await fetch(url); 
    
    // Storing data in form of JSON 
    var data = await response.json(); 
    console.log(data); 
    show(data); 
} 
// Calling that async function 
getapi(api_url);
function show(data){
    console.log(data);
}




                   