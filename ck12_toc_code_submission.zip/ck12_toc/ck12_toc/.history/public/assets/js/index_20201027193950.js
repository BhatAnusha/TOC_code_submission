// Your JS code goes here
var allData ={
    "maths": [
      {
        "childrenCount": 9,
        "id": 4443990,
        "sequenceNO": 1,
        "title": "Ratios",
        "type": "chapter",
        "completeCount": 9
      },
      {
        "childrenCount": 10,
        "id": 4443993,
        "sequenceNO": 2,
        "title": "Rates and Percentages",
        "type": "chapter",
        "completeCount": 4
      },
      {
        "childrenCount": 11,
        "id": 4429482,
        "sequenceNO": 3,
        "title": "Division with Fractions",
        "type": "chapter",
        "completeCount": 0
      },
      {
        "childrenCount": 10,
        "id": 4429484,
        "sequenceNO": 4,
        "title": "Operations with Decimals and Whole Numbers",
        "type": "chapter",
        "completeCount": 10
      },
      {
        "childrenCount": 11,
        "id": 4429490,
        "sequenceNO": 8,
        "title": "Rational Numbers",
        "type": "chapter",
        "completeCount": 2
      },
      {
        "childrenCount": 9,
        "id": 4429495,
        "sequenceNO": 6,
        "title": "Expressions",
        "type": "chapter",
        "completeCount": 4
      },
      {
        "childrenCount": 9,
        "id": 4429496,
        "sequenceNO": 7,
        "title": "Equations",
        "type": "chapter",
        "completeCount": 0
      },
      {
        "childrenCount": 0,
        "id": 1131520,
        "sequenceNO": 5,
        "title": "Fractions Explained in Depth",
        "type": "lesson",
        "status": "COMPLETE"
      }
    ]
  }

  show(allData)
function show(data){
    console.log(data.maths);
    for(let i=0;i<data.maths.length;i++){
        var empTab = document.getElementById('contentYellow');
        var li = document.createElement("li");
        var children = empTab.children.length + 1;
        li.setAttribute("id", "element" + children);
        li.setAttribute("class", "list-items");
        li.style.margin = "5px";
       
        empTab.appendChild(li);
        var liId = document.getElementById("element" + children);
        // ADD A BUTTON.
        var icon = document.createElement('i');
        icon.setAttribute('class', 'fa fa-plus');
        icon.style.display = "inline";
        
        var button1 = document.createElement('button');
        // SET INPUT ATTRIBUTE.
        button1.setAttribute('type', 'button');
        button1.setAttribute("id", "button" + children);
        button1.setAttribute('class', 'btn-default collapsible');
        button1.style.display = "inline";
        button1.style.marginTop = "-5px";
        button1.style.borderRadius = "5px";
        button1.appendChild(icon);
        button1.appendChild(document.createTextNode(data.maths[i].title));
        liId.appendChild(button1);
        //<i class="fa fa-plus"></i>
       
        cell.onclick = function() { clickTest(rowID); };



    }


    
  

    // var a = $(this).find("#element" + children);
    // var ListItems = $('#contentYellow').find("#element" + children);
    // while (ListItems.length !== 0) {
    //     //$("#element" + children).remove();
    //     var children = empTab.children.length + getRandomInt(20, 1000);
    //     li.setAttribute("id", "element" + children);
    //     var ListItems = $('#contentYellow').find("#element" + children);
    // }
    // li.setAttribute("class", "list-items");
    // li.style.margin = "5px";
    // //li.appendChild(document.createTextNode("Element "+children));
    // empTab.appendChild(li);
    // var liId = document.getElementById("element" + children);
    // $scope.idSend = document.getElementById("element" + children);
    // // ADD A BUTTON.
    // var button1 = document.createElement('button');
    // // SET INPUT ATTRIBUTE.
    // button1.setAttribute('type', 'button');
    // button1.setAttribute("id", "button" + children);
    // button1.setAttribute('class', 'btn btn-sm btn-default collapsible');
    // button1.style.display = "inline-block";
    // button1.style.marginTop = "-5px";
    // button1.style.borderRadius = "5px";
    // // ADD THE BUTTON's 'onclick' EVENT.
    // //button.setAttribute('ng-click', 'removeRow(this)');
    // liId.appendChild(button1);
    // var buttonId = document.getElementById("button" + children);
    // // compile the element
    // $compile($(buttonId))($scope);

    // // CREATE AND ADD TEXTBOX IN EACH CELL.
    // var ele1 = document.createElement('i');
    // ele1.setAttribute('class', 'fa fa-close');
    // ele1.style.display = "inline-block";
    // buttonId.appendChild(ele1);

    // // ADD A BUTTON.
    // var button = document.createElement('button');

    // // SET INPUT ATTRIBUTE.
    // button.setAttribute('type', 'button');
    // button.setAttribute("id", "buttonAdd" + children);
    // button.setAttribute('class', 'btn btn-sm btn-default');
    // button.style.display = "inline-block";
    // button.style.marginTop = "-5px";
    // button.style.borderRadius = "5px";
    // // ADD THE BUTTON's 'onclick' EVENT.
    // liId.appendChild(button);
    // var buttonAddId = document.getElementById("buttonAdd" + children);
    // //Creating another icon to add
    // var ele2 = document.createElement('i');
    // ele2.setAttribute('class', 'fa fa-plus');
    // ele2.style.display = "inline-block";
    // buttonAddId.appendChild(ele2);
    // // change ng-click
    // $(buttonAddId).attr('ng-click', 'addRow()');
    // // compile the element
    // $compile($(buttonAddId))($scope);

    // // CREATE AND ADD TEXTBOX IN EACH CELL.
    // var ele = document.createElement('input');
    // ele.setAttribute('type', 'text');
    // ele.setAttribute('class', 'form-control');
    // ele.setAttribute("id", "input" + children);
    // ele.setAttribute("ng-model", "row" + children);
    // ele.setAttribute("value", "");
    // ele.setAttribute("placeholder", "Add a Yellow Label");
    // var variable = "row" + children;
    // $scope[variable] = "";
    // ele.style.width = "89%";
    // ele.style.display = "inline-block";
    // ele.style.borderRadius = "5px";
    // ele.style.height = "30px";
    // liId.appendChild(ele);
    // var inputId = document.getElementById("input" + children);
    // $scope.inputTypeId = document.getElementById("input" + children);
    // //$(inputId).attr('required','required');
    // $(inputId).attr('ng-change', 'changeRow(row' + children + ',this)');
    // $compile($(inputId))($scope);
}

var coll = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var content = this.nextElementSibling;
    if (content.style.display === "block") {
      content.style.display = "none";
    } else {
      content.style.display = "block";
    }
  });
}




                   